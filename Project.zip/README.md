The python scripts are all independent and are each designed to be their own experiment with the pre-processed data.
The R project was used to pre-process the data, split into subsets, and remove outliers.
We cannot give the data away as that violates the NDA and privacy contract we have with First Orion